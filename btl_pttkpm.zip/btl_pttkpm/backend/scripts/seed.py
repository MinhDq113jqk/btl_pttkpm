from datetime import date
from decimal import Decimal
import json
import sys
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import Settings
from app.core.database import Database
from app.core.security import hash_password, verify_password
from app.models.account import Account, AccountRole
from app.models.billing import AccountingPeriod, BillingAccount, FeePolicy, FeePolicyVersion
from app.models.building import Building
from app.models.enums import RelationshipTypeEnum, RoleEnum, UnitStatusEnum
from app.models.person import Person, UnitPersonRelationship
from app.models.operations import CleaningArea, CleaningRoute, CleaningRouteStop, PatrolPoint
from app.models.site import Site
from app.models.service import ServiceCategory
from app.models.tenant import Tenant
from app.models.unit import Unit


DEMO_ACCOUNT_USERNAMES = (
    "admin_demo",
    "director_west",
    "cskh_west",
    "cskh_east",
    "accountant_west",
    "techlead_west",
    "technician_west",
    "cleaning_west",
    "security_west",
    "resident_west",
)


def load_demo_seed_credentials(settings: Settings) -> dict[str, str]:
    """Load one distinct, source-external credential per demo account."""
    if settings.app_env not in {"development", "test"}:
        raise RuntimeError("Demo seed is permitted only in development or test environments")
    if not settings.demo_seed_enabled:
        raise RuntimeError("Demo seed is disabled; set DEMO_SEED_ENABLED=true explicitly")
    if settings.demo_seed_credentials_json is None:
        raise RuntimeError("Demo seed credentials are required and must stay outside source control")
    try:
        raw_credentials = json.loads(settings.demo_seed_credentials_json.get_secret_value())
    except (TypeError, json.JSONDecodeError):
        raise ValueError("Demo seed credentials must be valid JSON") from None
    if not isinstance(raw_credentials, dict) or set(raw_credentials) != set(DEMO_ACCOUNT_USERNAMES):
        raise ValueError("Demo seed credentials must contain exactly the configured demo usernames")
    credentials = {username: raw_credentials[username] for username in DEMO_ACCOUNT_USERNAMES}
    if any(not isinstance(password, str) or len(password.encode("utf-8")) < 16
           for password in credentials.values()):
        raise ValueError("Each demo seed credential must be a distinct string of at least 16 bytes")
    if len(set(credentials.values())) != len(credentials):
        raise ValueError("Each demo account requires a distinct credential")
    return credentials


def seed_database(session: Session, demo_credentials: dict[str, str]) -> None:
    # 1. Tenant
    tenant = session.execute(
        select(Tenant).where(Tenant.name == "GreenCity Corporation")
    ).scalar_one_or_none()
    if not tenant:
        tenant = Tenant(name="GreenCity Corporation")
        session.add(tenant)
        session.flush()

    # 2. Two Sites: West (Demo) & East (Isolation Test)
    site_west = session.execute(
        select(Site).where(Site.tenant_id == tenant.id, Site.code == "GC-WEST")
    ).scalar_one_or_none()
    if not site_west:
        site_west = Site(
            tenant_id=tenant.id,
            code="GC-WEST",
            name="GreenCity West Đô Thị Mẫu",
            address="Đại lộ Ánh Sao, Khu đô thị Tây GreenCity, Hà Nội",
        )
        session.add(site_west)
        session.flush()

    site_east = session.execute(
        select(Site).where(Site.tenant_id == tenant.id, Site.code == "GC-EAST")
    ).scalar_one_or_none()
    if not site_east:
        site_east = Site(
            tenant_id=tenant.id,
            code="GC-EAST",
            name="GreenCity East Kiểm Thử Cô Lập",
            address="Đường Hoa Ban, Khu đô thị Đông GreenCity, Hà Nội",
        )
        session.add(site_east)
        session.flush()

    # 3. Buildings
    building_w1 = session.execute(
        select(Building).where(Building.site_id == site_west.id, Building.code == "W1")
    ).scalar_one_or_none()
    if not building_w1:
        building_w1 = Building(
            site_id=site_west.id,
            code="W1",
            name="Tòa Tháp Ruby W1",
            floors_count=25,
        )
        session.add(building_w1)
        session.flush()

    building_e1 = session.execute(
        select(Building).where(Building.site_id == site_east.id, Building.code == "E1")
    ).scalar_one_or_none()
    if not building_e1:
        building_e1 = Building(
            site_id=site_east.id,
            code="E1",
            name="Tòa Tháp Diamond E1",
            floors_count=20,
        )
        session.add(building_e1)
        session.flush()

    # R2 request taxonomy is site-scoped and intentionally contains no PII.
    for site, building in ((site_west, building_w1), (site_east, building_e1)):
        category = session.execute(select(ServiceCategory).where(
            ServiceCategory.tenant_id == tenant.id,
            ServiceCategory.site_id == site.id,
            ServiceCategory.code == "TECHNICAL",
        )).scalar_one_or_none()
        if category is None:
            session.add(ServiceCategory(
                tenant_id=tenant.id,
                site_id=site.id,
                building_id=building.id,
                code="TECHNICAL",
                name="Yêu cầu kỹ thuật",
                sla_minutes=240,
                is_active=True,
                version=1,
            ))

        # Seed catalogues only; operational history is created by R3 flows.
        route = session.execute(select(CleaningRoute).where(
            CleaningRoute.tenant_id == tenant.id,
            CleaningRoute.site_id == site.id,
            CleaningRoute.code == "CLN-LOBBY",
        )).scalar_one_or_none()
        if route is None:
            route = CleaningRoute(
                tenant_id=tenant.id, site_id=site.id, building_id=building.id,
                code="CLN-LOBBY", name="Tuyến sảnh chính", is_active=True, version=1,
            )
            session.add(route)
            session.flush()

        area = session.execute(select(CleaningArea).where(
            CleaningArea.tenant_id == tenant.id,
            CleaningArea.site_id == site.id,
            CleaningArea.code == "LOBBY",
        )).scalar_one_or_none()
        if area is None:
            area = CleaningArea(
                tenant_id=tenant.id, site_id=site.id, building_id=building.id,
                code="LOBBY", name="Sảnh chính", is_active=True, version=1,
            )
            session.add(area)
            session.flush()

        route_stop = session.execute(select(CleaningRouteStop).where(
            CleaningRouteStop.route_id == route.id,
            CleaningRouteStop.cleaning_area_id == area.id,
        )).scalar_one_or_none()
        if route_stop is None:
            session.add(CleaningRouteStop(
                tenant_id=tenant.id, site_id=site.id, building_id=building.id,
                route_id=route.id, cleaning_area_id=area.id, position=1,
                checklist_template=[
                    {"label": "Sàn sạch và khô", "required": True},
                    {"label": "Thùng rác đã kiểm tra", "required": True},
                ],
                version=1,
            ))

        patrol_point = session.execute(select(PatrolPoint).where(
            PatrolPoint.tenant_id == tenant.id,
            PatrolPoint.site_id == site.id,
            PatrolPoint.code == "SEC-LOBBY",
        )).scalar_one_or_none()
        if patrol_point is None:
            session.add(PatrolPoint(
                tenant_id=tenant.id, site_id=site.id, building_id=building.id,
                code="SEC-LOBBY", name="Điểm tuần tra sảnh chính", is_active=True, version=1,
            ))

    # 4. Units
    unit_w101 = session.execute(
        select(Unit).where(Unit.building_id == building_w1.id, Unit.unit_number == "W1-0101")
    ).scalar_one_or_none()
    if not unit_w101:
        unit_w101 = Unit(
            building_id=building_w1.id,
            unit_number="W1-0101",
            floor=1,
            area_m2=78.5,
            status=UnitStatusEnum.OCCUPIED,
            version=1,
        )
        session.add(unit_w101)
        session.flush()

    unit_w102 = session.execute(
        select(Unit).where(Unit.building_id == building_w1.id, Unit.unit_number == "W1-0102")
    ).scalar_one_or_none()
    if not unit_w102:
        unit_w102 = Unit(
            building_id=building_w1.id,
            unit_number="W1-0102",
            floor=1,
            area_m2=81.25,
            status=UnitStatusEnum.OCCUPIED,
            version=1,
        )
        session.add(unit_w102)
        session.flush()

    unit_w103 = session.execute(
        select(Unit).where(Unit.building_id == building_w1.id, Unit.unit_number == "W1-0103")
    ).scalar_one_or_none()
    if not unit_w103:
        unit_w103 = Unit(
            building_id=building_w1.id,
            unit_number="W1-0103",
            floor=1,
            area_m2=69.75,
            status=UnitStatusEnum.OCCUPIED,
            version=1,
        )
        session.add(unit_w103)
        session.flush()

    unit_e101 = session.execute(
        select(Unit).where(Unit.building_id == building_e1.id, Unit.unit_number == "E1-0201")
    ).scalar_one_or_none()
    if not unit_e101:
        unit_e101 = Unit(
            building_id=building_e1.id,
            unit_number="E1-0201",
            floor=2,
            area_m2=92.0,
            status=UnitStatusEnum.OCCUPIED,
            version=1,
        )
        session.add(unit_e101)
        session.flush()

    # 5. Persons & Unit Relationships (No real PII)
    person_an = session.execute(
        select(Person).where(Person.tenant_id == tenant.id, Person.phone_masked == "090***0001")
    ).scalar_one_or_none()
    if not person_an:
        person_an = Person(
            tenant_id=tenant.id,
            full_name="Nguyễn Văn An",
            phone_masked="090***0001",
            email_masked="an.nv***@greencity.vn",
        )
        session.add(person_an)
        session.flush()

    rel_w101 = session.execute(
        select(UnitPersonRelationship).where(
            UnitPersonRelationship.unit_id == unit_w101.id,
            UnitPersonRelationship.person_id == person_an.id,
        )
    ).scalar_one_or_none()
    if not rel_w101:
        rel_w101 = UnitPersonRelationship(
            unit_id=unit_w101.id,
            person_id=person_an.id,
            relationship_type=RelationshipTypeEnum.OWNER,
            ownership_ratio=Decimal("1.0000"),
            valid_from=date(2025, 1, 1),
        )
        session.add(rel_w101)

    for unit, relationship_type, ownership_ratio in (
        (unit_w102, RelationshipTypeEnum.OWNER, Decimal("0.5000")),
        (unit_w103, RelationshipTypeEnum.TENANT, None),
    ):
        relationship = session.execute(
            select(UnitPersonRelationship).where(
                UnitPersonRelationship.unit_id == unit.id,
                UnitPersonRelationship.person_id == person_an.id,
                UnitPersonRelationship.relationship_type == relationship_type,
                UnitPersonRelationship.valid_from == date(2025, 1, 1),
            )
        ).scalar_one_or_none()
        if relationship is None:
            session.add(UnitPersonRelationship(
                unit_id=unit.id,
                person_id=person_an.id,
                relationship_type=relationship_type,
                ownership_ratio=ownership_ratio,
                valid_from=date(2025, 1, 1),
            ))

    person_binh = session.execute(
        select(Person).where(Person.tenant_id == tenant.id, Person.phone_masked == "090***0002")
    ).scalar_one_or_none()
    if not person_binh:
        person_binh = Person(
            tenant_id=tenant.id,
            full_name="Trần Thị Bình",
            phone_masked="090***0002",
            email_masked="binh.tt***@greencity.vn",
        )
        session.add(person_binh)
        session.flush()

    rel_e101 = session.execute(
        select(UnitPersonRelationship).where(
            UnitPersonRelationship.unit_id == unit_e101.id,
            UnitPersonRelationship.person_id == person_binh.id,
        )
    ).scalar_one_or_none()
    if not rel_e101:
        rel_e101 = UnitPersonRelationship(
            unit_id=unit_e101.id,
            person_id=person_binh.id,
            relationship_type=RelationshipTypeEnum.OWNER,
            ownership_ratio=Decimal("1.0000"),
            valid_from=date(2025, 1, 1),
        )
        session.add(rel_e101)

    # 6. Accounts and Roles. Credentials are injected by the explicit seed
    # guard above; do not add a source-derived fallback here.
    accounts_data = [
        ("admin_demo", "Quản Trị Viên Demo", [RoleEnum.ADMIN], None),
        ("director_west", "Giám Đốc BQL West", [RoleEnum.DIRECTOR], site_west.id),
        ("cskh_west", "Lễ Tân CSKH West", [RoleEnum.CSKH], site_west.id),
        ("cskh_east", "Lễ Tân CSKH East", [RoleEnum.CSKH], site_east.id),
        ("accountant_west", "Kế Toán Viên West", [RoleEnum.ACCOUNTANT], site_west.id),
        ("techlead_west", "Trưởng Kỹ Thuật West", [RoleEnum.TECHNICAL_LEAD], site_west.id),
        ("technician_west", "Kỹ Thuật Viên West", [RoleEnum.TECHNICIAN], site_west.id),
        ("cleaning_west", "Nhân Viên Vệ Sinh West", [RoleEnum.CLEANING], site_west.id),
        ("security_west", "Nhân Viên An Ninh West", [RoleEnum.SECURITY], site_west.id),
    ]

    for username, full_name, roles, site_id in accounts_data:
        account = session.execute(
            select(Account).where(Account.tenant_id == tenant.id, Account.username == username)
        ).scalar_one_or_none()
        if not account:
            account = Account(
                tenant_id=tenant.id,
                username=username,
                hashed_password=hash_password(demo_credentials[username]),
                full_name=full_name,
                is_active=True,
                must_change_password=True,
            )
            session.add(account)
            session.flush()
        elif not verify_password(demo_credentials[username], account.hashed_password):
            # Do not silently rotate an existing credential: it hides an
            # operationally important change and would make repeat seed unsafe.
            raise RuntimeError(
                f"Existing demo account {username!r} has a different credential; "
                "use an explicit rotation or rebuild the disposable database"
            )

        # Provision only these named demo accounts; never infer scope for arbitrary
        # existing users. Legacy site-only grants for building roles remain inert.
        for role in roles:
            building_id = None
            if role in {RoleEnum.CSKH, RoleEnum.TECHNICAL_LEAD, RoleEnum.SECURITY}:
                building_id = building_w1.id if site_id == site_west.id else building_e1.id
            existing_grant = session.execute(select(AccountRole).where(
                AccountRole.account_id == account.id, AccountRole.role == role,
                AccountRole.site_id == site_id, AccountRole.building_id == building_id,
            )).scalar_one_or_none()
            if existing_grant is None:
                acc_role = AccountRole(
                    account_id=account.id,
                    role=role,
                    site_id=site_id,
                    building_id=building_id,
                )
                session.add(acc_role)

    # R6 resident demo identity: link through the trusted Person relationship
    # created above.  Re-running seed is safe; a conflicting existing link is
    # rejected rather than silently widening a resident's scope.
    resident_account = session.execute(select(Account).where(
        Account.tenant_id == tenant.id,
        Account.username == "resident_west",
    )).scalar_one_or_none()
    if resident_account is None:
        resident_account = Account(
            tenant_id=tenant.id,
            username="resident_west",
            hashed_password=hash_password(demo_credentials["resident_west"]),
            full_name=person_an.full_name,
            is_active=True,
            must_change_password=True,
            person_id=person_an.id,
        )
        session.add(resident_account)
        session.flush()
    elif not verify_password(demo_credentials["resident_west"], resident_account.hashed_password):
        raise RuntimeError(
            "Existing demo account 'resident_west' has a different credential; "
            "use an explicit rotation or rebuild the disposable database"
        )
    elif resident_account.person_id not in (None, person_an.id):
        raise ValueError("resident_west is already linked to a different Person")
    elif resident_account.person_id is None:
        resident_account.person_id = person_an.id
        session.flush()
    resident_role = session.execute(select(AccountRole).where(
        AccountRole.account_id == resident_account.id,
        AccountRole.role == RoleEnum.RESIDENT,
        AccountRole.site_id == site_west.id,
        AccountRole.building_id == building_w1.id,
    )).scalar_one_or_none()
    if resident_role is None:
        session.add(AccountRole(
            account_id=resident_account.id,
            role=RoleEnum.RESIDENT,
            site_id=site_west.id,
            building_id=building_w1.id,
        ))

    # R4 seeds only stable billing setup. It never creates invoice, payment,
    # allocation, credit, unmatched-payment, or AR-ledger history.
    for site, building, unit in (
        (site_west, building_w1, unit_w101),
        (site_east, building_e1, unit_e101),
    ):
        billing_account = session.execute(select(BillingAccount).where(
            BillingAccount.building_id == building.id,
            BillingAccount.unit_id == unit.id,
        )).scalar_one_or_none()
        if billing_account is None:
            session.add(BillingAccount(
                tenant_id=tenant.id,
                site_id=site.id,
                building_id=building.id,
                unit_id=unit.id,
                account_number=f"BA-{unit.unit_number}",
                status="ACTIVE",
                opened_on=date(2025, 1, 1),
                version=1,
            ))

        policy = session.execute(select(FeePolicy).where(
            FeePolicy.building_id == building.id,
            FeePolicy.code == "MGMT-MONTHLY",
        )).scalar_one_or_none()
        if policy is None:
            policy = FeePolicy(
                tenant_id=tenant.id,
                site_id=site.id,
                building_id=building.id,
                code="MGMT-MONTHLY",
                name="Phí quản lý tháng",
                is_active=True,
            )
            session.add(policy)
            session.flush()
        if session.execute(select(FeePolicyVersion).where(
            FeePolicyVersion.fee_policy_id == policy.id,
            FeePolicyVersion.version_number == 1,
        )).scalar_one_or_none() is None:
            session.add(FeePolicyVersion(
                tenant_id=tenant.id,
                site_id=site.id,
                building_id=building.id,
                fee_policy_id=policy.id,
                version_number=1,
                effective_from=date(2025, 1, 1),
                unit_rate_vnd=0,
                version=1,
            ))

        if session.execute(select(AccountingPeriod).where(
            AccountingPeriod.building_id == building.id,
            AccountingPeriod.period_key == "2026-09",
        )).scalar_one_or_none() is None:
            session.add(AccountingPeriod(
                tenant_id=tenant.id,
                site_id=site.id,
                building_id=building.id,
                period_key="2026-09",
                period_start=date(2026, 9, 1),
                period_end=date(2026, 9, 30),
                status="OPEN",
                version=1,
            ))

    session.commit()
    print("Idempotent seed completed successfully!")


if __name__ == "__main__":
    settings = Settings()
    credentials = load_demo_seed_credentials(settings)
    db = Database(settings)
    try:
        with db.get_session() as s:
            seed_database(s, credentials)
    finally:
        db.close()
