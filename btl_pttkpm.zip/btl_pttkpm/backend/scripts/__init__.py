"""Local operational checks."""
