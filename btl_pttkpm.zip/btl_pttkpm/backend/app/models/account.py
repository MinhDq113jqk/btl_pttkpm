from uuid import UUID

from sqlalchemy import Boolean, CheckConstraint, ForeignKey, ForeignKeyConstraint, Index, Integer, String, UniqueConstraint, Uuid
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.models.base import Base, IdentityTimestampMixin


class Account(IdentityTimestampMixin, Base):
    __tablename__ = "accounts"
    __table_args__ = (
        UniqueConstraint("tenant_id", "username", name="uq_accounts_tenant_id_username"),
        UniqueConstraint("id", "tenant_id", name="uq_accounts_id_tenant_id"),
        UniqueConstraint("tenant_id", "person_id", name="uq_accounts_tenant_id_person_id"),
        ForeignKeyConstraint(
            ["person_id", "tenant_id"], ["greencity.persons.id", "greencity.persons.tenant_id"],
            name="fk_accounts_person_tenant", ondelete="RESTRICT",
        ),
        Index("ix_greencity_accounts_tenant_id", "tenant_id"),
        Index("ix_greencity_accounts_person_id", "person_id"),
        CheckConstraint("session_version >= 1", name="accounts_session_version_positive"),
    )

    tenant_id: Mapped[UUID] = mapped_column(ForeignKey("greencity.tenants.id", ondelete="CASCADE"), nullable=False)
    username: Mapped[str] = mapped_column(String(100), nullable=False)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    full_name: Mapped[str] = mapped_column(String(200), nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    session_version: Mapped[int] = mapped_column(Integer, nullable=False, default=1, server_default="1")
    must_change_password: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False, server_default="false")
    # A resident identity is assigned by a trusted back-office path, never by a
    # login request or token claim.  The composite FK keeps it in this tenant.
    person_id: Mapped[UUID | None] = mapped_column(Uuid, nullable=True)

    roles = relationship("AccountRole", backref="account", cascade="all, delete-orphan")


class AccountRole(IdentityTimestampMixin, Base):
    __tablename__ = "account_roles"
    __table_args__ = (
        CheckConstraint("building_id IS NULL OR site_id IS NOT NULL", name="building_requires_site"),
        ForeignKeyConstraint(["building_id", "site_id"],
                             ["greencity.buildings.id", "greencity.buildings.site_id"],
                             name="fk_account_roles_building_site", ondelete="CASCADE"),
        Index("ix_greencity_account_roles_account_id", "account_id"),
        Index("ix_greencity_account_roles_site_id", "site_id"),
    )

    account_id: Mapped[UUID] = mapped_column(ForeignKey("greencity.accounts.id", ondelete="CASCADE"), nullable=False)
    role: Mapped[str] = mapped_column(String(50), nullable=False)
    site_id: Mapped[UUID | None] = mapped_column(ForeignKey("greencity.sites.id", ondelete="CASCADE"), nullable=True)
    building_id: Mapped[UUID | None] = mapped_column(Uuid, nullable=True, index=True)

    site = relationship("Site")
