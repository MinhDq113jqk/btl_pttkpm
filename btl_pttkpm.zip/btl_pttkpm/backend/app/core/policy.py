from dataclasses import dataclass
from datetime import date
from datetime import UTC, datetime
import time
from uuid import UUID

from fastapi import Header, Request
from sqlalchemy import and_, or_, select
from sqlalchemy.orm import Session

from app.core.exceptions import AppError
from app.core.security import decode_token
from app.models.account import Account, AccountRole
from app.models.auth_session import AuthSession
from app.models.building import Building
from app.models.enums import RoleEnum
from app.models.person import UnitPersonRelationship
from app.models.site import Site
from app.models.unit import Unit

UNIT_READ_ROLES = frozenset({"admin", "director", "cskh", "accountant",
                             "technical_lead", "technician", "security"})
SITE_WIDE_UNIT_ROLES = frozenset({"admin", "director", "accountant"})
BUILDING_UNIT_ROLES = frozenset({"cskh", "technical_lead", "security"})
RESIDENT_READ_ROLES = frozenset({"admin", "director", "cskh", "accountant"})
RESIDENT_ROLE = RoleEnum.RESIDENT.value
PASSWORD_CHANGE_ALLOWED_ROUTES = frozenset({
    "/auth/me", "/auth/change-password", "/auth/logout",
})


@dataclass(frozen=True)
class UnitGrant:
    role: str
    building_id: UUID | None


def scope_not_found() -> AppError:
    return AppError("ERR-SCOPE-NOTFOUND", "Không tìm thấy dữ liệu.", 404)


@dataclass
class UserContext:
    account_id: UUID
    tenant_id: UUID
    username: str
    full_name: str
    roles: list[str]
    active_site_id: UUID | None
    # Concrete tenant-validated IDs. Legacy None fails closed, never a wildcard.
    allowed_site_ids: list[UUID] | None
    unit_grants: tuple[UnitGrant, ...] = ()
    role_grants: tuple[UnitGrant, ...] = ()
    resident_person_id: UUID | None = None
    resident_unit_ids: tuple[UUID, ...] = ()
    must_change_password: bool = False

    def is_admin(self) -> bool:
        return "admin" in self.roles

    def can_access_site(self, site_id: UUID) -> bool:
        return site_id in (self.allowed_site_ids or [])

    def assert_site_access(self, site_id: UUID) -> None:
        if not self.can_access_site(site_id):
            raise scope_not_found()

    def assert_role(self, *required_roles: str) -> None:
        if not any(role in self.roles for role in required_roles):
            raise AppError("ERR-FORBIDDEN", "Bạn không có quyền thực hiện thao tác này", 403)

    def assert_active_site(self) -> UUID:
        if self.active_site_id is None or not self.can_access_site(self.active_site_id):
            raise scope_not_found()
        return self.active_site_id

    def matching_grants(self, roles: set[str] | frozenset[str], building_id: UUID) -> tuple[UnitGrant, ...]:
        return tuple(grant for grant in self.role_grants
                     if grant.role in roles
                     and (grant.building_id == building_id
                          or (grant.building_id is None and grant.role not in BUILDING_UNIT_ROLES)))

    def assert_building_role(self, building_id: UUID, *required_roles: str) -> None:
        self.assert_active_site()
        self.assert_role(*required_roles)
        if not self.matching_grants(frozenset(required_roles), building_id):
            raise scope_not_found()

    def scope_conditions(self, model):
        return (
            model.tenant_id == self.tenant_id,
            model.site_id == self.assert_active_site(),
        )

    def sites_query(self):
        return select(Site).where(
            Site.tenant_id == self.tenant_id,
            Site.id.in_(self.allowed_site_ids or []),
        ).order_by(Site.code, Site.id)

    def units_query(self):
        self.assert_role(*UNIT_READ_ROLES)
        if not self.unit_grants:
            # Includes technician: no genuine WO assignment exists in R1 yet.
            raise scope_not_found()
        building_scope = or_(*[
            Building.id == grant.building_id if grant.building_id is not None else True
            for grant in self.unit_grants
        ])
        # Filter BEFORE loading Person relationships; an ID is never authorization.
        return select(Unit).join(Building, Unit.building_id == Building.id).join(
            Site, Building.site_id == Site.id,
        ).where(
            Site.tenant_id == self.tenant_id,
            Site.id.in_(self.allowed_site_ids or []),
            Site.id == self.active_site_id,
            building_scope,
        )

    def unit_projection(self, building_id: UUID) -> tuple[bool, bool]:
        """Return (residents visible, full unit details) for this target ONLY."""
        matched = [grant for grant in self.unit_grants
                   if grant.building_id is None or grant.building_id == building_id]
        return (any(grant.role in RESIDENT_READ_ROLES for grant in matched),
                any(grant.role != "security" for grant in matched))


def context_for_account(session: Session, account: Account,
                        active_site_id: UUID | None = None) -> UserContext:
    # Tenant-wide admin is an explicit grant (site_id NULL). Site-specific admin
    # roles must never become tenant-wide or grant roles in another active site.
    valid_building = or_(AccountRole.building_id.is_(None),
                        AccountRole.building_id.in_(select(Building.id).where(
                            Building.site_id == AccountRole.site_id)))
    known_role = AccountRole.role.in_([role.value for role in RoleEnum])
    resident_role_exists = session.scalar(select(AccountRole.id).where(
        AccountRole.account_id == account.id,
        AccountRole.role == RESIDENT_ROLE,
        valid_building,
    ).limit(1)) is not None
    resident_scope_rows = ()
    if resident_role_exists and account.person_id is not None:
        # Authorization is effective now, so a former resident loses access
        # immediately even if an already-issued session token is replayed.
        resident_scope_rows = session.execute(select(
            UnitPersonRelationship.site_id,
            UnitPersonRelationship.unit_id,
        ).distinct().where(
            UnitPersonRelationship.person_id == account.person_id,
            UnitPersonRelationship.tenant_id == account.tenant_id,
            UnitPersonRelationship.valid_from <= date.today(),
            or_(
                UnitPersonRelationship.valid_to.is_(None),
                UnitPersonRelationship.valid_to > date.today(),
            ),
        )).all()
    grant = select(AccountRole.id).where(
        AccountRole.account_id == account.id,
        valid_building,
        known_role,
        or_(AccountRole.site_id == Site.id,
            and_(AccountRole.role == "admin", AccountRole.site_id.is_(None))),
    ).exists()
    sites = session.scalars(select(Site).where(
        Site.tenant_id == account.tenant_id, grant,
    ).order_by(Site.code, Site.id)).all()
    site_ids = [site.id for site in sites]
    for resident_site_id in sorted({row.site_id for row in resident_scope_rows}, key=str):
        if resident_site_id not in site_ids:
            site_ids.append(resident_site_id)
    if active_site_id is not None and active_site_id not in site_ids:
        raise scope_not_found()
    if active_site_id is None:
        active_site_id = site_ids[0] if site_ids else None
    role_scope = AccountRole.site_id == active_site_id if active_site_id else False
    roles = session.scalars(select(AccountRole).where(
        AccountRole.account_id == account.id,
        valid_building,
        known_role,
        or_(role_scope, and_(AccountRole.role == "admin", AccountRole.site_id.is_(None))),
    )).all()
    resident_unit_ids = tuple(
        row.unit_id for row in resident_scope_rows if row.site_id == active_site_id
    )
    role_names = {grant.role for grant in roles}
    if resident_unit_ids:
        role_names.add(RESIDENT_ROLE)
    role_grants = tuple(UnitGrant(grant.role, grant.building_id) for grant in roles)
    unit_grants = tuple(UnitGrant(grant.role, grant.building_id) for grant in roles
                        if grant.role in SITE_WIDE_UNIT_ROLES
                        or (grant.role in BUILDING_UNIT_ROLES and grant.building_id is not None))
    return UserContext(
        account_id=account.id,
        tenant_id=account.tenant_id,
        username=account.username,
        full_name=account.full_name,
        roles=sorted(role_names),
        active_site_id=active_site_id,
        allowed_site_ids=site_ids,
        unit_grants=unit_grants,
        role_grants=role_grants,
        resident_person_id=account.person_id if resident_unit_ids else None,
        resident_unit_ids=resident_unit_ids,
        must_change_password=account.must_change_password,
    )


def get_current_user_context(
    request: Request,
    authorization: str | None = Header(None, alias="Authorization"),
) -> UserContext:
    if not authorization or not authorization.startswith("Bearer "):
        raise AppError("ERR-UNAUTHORIZED", "Yêu cầu đăng nhập để truy cập tài nguyên", 401)
    claims = decode_token(authorization[len("Bearer "):].strip(),
                          request.app.state.settings.auth_secret())
    # Signed download tokens share the signing key but are not browser/API
    # sessions.  A URL token must never become a temporary bearer credential.
    if claims.get("purpose") != "session":
        raise AppError("ERR-UNAUTHORIZED", "Token không hợp lệ", 401)
    session_id = claims.get("sid")
    session_version = claims.get("sv")
    issued_at = claims.get("iat")
    if (not isinstance(session_id, str) or type(session_version) is not int or session_version < 1
            or type(issued_at) is not int or issued_at > time.time() + 60):
        raise AppError("ERR-UNAUTHORIZED", "Token không hợp lệ", 401)
    try:
        session_id = UUID(session_id)
    except ValueError:
        raise AppError("ERR-UNAUTHORIZED", "Token không hợp lệ", 401) from None
    # decode_token validates claim types; role and tenant claims are never trusted.
    with request.app.state.database.get_session() as session:
        account = session.scalar(select(Account).where(
            Account.id == UUID(claims["sub"]), Account.is_active.is_(True),
        ))
        now = datetime.now(UTC)
        auth_session = session.scalar(select(AuthSession).where(
            AuthSession.id == session_id,
            AuthSession.account_id == UUID(claims["sub"]),
            AuthSession.session_version == session_version,
            AuthSession.revoked_at.is_(None),
            AuthSession.expires_at > now,
        ))
        if account is None or account.session_version != session_version or auth_session is None:
            raise AppError("ERR-UNAUTHORIZED", "Tài khoản không tồn tại hoặc đã bị khóa", 401)
        active_site_id = UUID(claims["active_site_id"]) if claims.get("active_site_id") else None
        context = context_for_account(session, account, active_site_id)
        route_path = getattr(request.scope.get("route"), "path", request.url.path)
        if route_path.startswith("/api/v1/"):
            route_path = route_path[len("/api/v1"):]
        if context.must_change_password and route_path not in PASSWORD_CHANGE_ALLOWED_ROUTES:
            raise AppError(
                "ERR-PASSWORD-CHANGE-REQUIRED",
                "Hãy đổi mật khẩu trước khi tiếp tục sử dụng GreenCity.",
                403,
            )
        request.state.auth_session_id = auth_session.id
    request.state.user_id = str(context.account_id)
    return context
