"""Shared backend infrastructure."""
